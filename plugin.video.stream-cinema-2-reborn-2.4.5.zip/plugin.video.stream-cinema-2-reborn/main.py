import xbmcaddon, xbmcplugin, xbmcgui, sys

_url = sys.argv[0]
_handle = int(sys.argv[1])
_addon = xbmcaddon.Addon()
_path = 'special://home/addons/'+_addon.getAddonInfo('id')+'/resources/'

def addMenuItem(icon, label):
    list_item = xbmcgui.ListItem(label=_addon.getLocalizedString(label))
    list_item.setArt({'icon': _path + icon})
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(_handle, _url+'?action=play', list_item, False)

if __name__ == '__main__':
    if sys.argv[2][1:]:
        xbmcplugin.setResolvedUrl(_handle, True, xbmcgui.ListItem(path=_path+'reborn.mp4'))
        sys.exit()
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name'))
    addMenuItem("search.png", 30204)
    addMenuItem("search-history-1.png", 30205)
    addMenuItem("movies.png", 30200)
    addMenuItem("tvshows.png", 30201)
    addMenuItem("music.png", 30174)
    addMenuItem("tv-program.png", 30398)
    addMenuItem("thematic_lists.png", 32413)
    addMenuItem("download.png", 30622)
    addMenuItem("settings.png", 30208)
    xbmcplugin.endOfDirectory(_handle)
    