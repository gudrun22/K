# archivczsk-doplnky
Doplňky pro archivczsk Enigma2 plugin.

Tyto doplňky neposkytují žádný obsah, jen simulují prohlížeč veřejně dostupné web stránky resp. android/ios aplikace. Žádný z autorů jednotlivých doplňků není zodpovědný za obsah, který tato stránka/aplikace poskytuje.

## Podpora
Ak máte problém, tak podporu môžete hľadať fóre **CS Fórum** https://cs-forum.eu/viewforum.php?f=58

### Vylepšený exteplayer3
Niektoré doplnky vyžadujú vylepšený [exteplayer3](https://github.com/archivczsk/archivczsk/wiki/ServiceApp#vylepšený-exteplayer3) s podporou prehrávania DRM obsahu
